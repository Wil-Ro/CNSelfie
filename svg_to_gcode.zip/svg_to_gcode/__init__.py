TOLERANCES = {"approximation": 10 ** -2, "input": 10 ** -3, "operation": 10**-6}
UNITS = {"mm", "in"}
