"""The compiler sub-module transforms geometric Curves into CAM machine code."""

from svg_to_gcode.compiler._compiler import Compiler
